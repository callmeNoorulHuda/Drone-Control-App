import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:easy_localization/easy_localization.dart';
import '../connection/connection_manager.dart';
import '../state/connection_status.dart';
import '../state/joystick_controller.dart';
import '../state/settings_controller.dart';
import '../state/vehicle_state.dart';
import '../models/health_state.dart';
import '../theme/app_theme.dart';
import '../theme/responsive.dart';
import '../widgets/camera_feed_panel.dart';
import '../widgets/drone_map_view.dart';
import '../widgets/flight_status_panel.dart';
import '../widgets/telemetry_panel.dart';
import '../widgets/top_bar.dart';
import '../widgets/virtual_joystick.dart';
import '../widgets/arrow_joystick.dart';
import '../state/joystick_style.dart';

class MainFlightScreen extends StatefulWidget {
  const MainFlightScreen({super.key});

  @override
  State<MainFlightScreen> createState() => _MainFlightScreenState();
}

class _MainFlightScreenState extends State<MainFlightScreen>
    with WidgetsBindingObserver {
  bool _forceIdleThrottleForArming = false;
  final JoystickController _leftController = JoystickController();
  final JoystickController _rightController = JoystickController();
  final GlobalKey<DroneMapViewState> _mapKey = GlobalKey<DroneMapViewState>();

  // No longer created here — sourced from Provider (see main.dart), since
  // they now live for the whole app's lifetime, not just this screen's.
  late final VehicleState _vehicleState;
  late final ConnectionManager _connectionManager;

  String? _lastShownError;
  VehicleAlert? _lastProcessedAlert;
  bool _timedOutDialogShown = false;

  // Manual = joysticks + arm/disarm + flight-mode chips are shown.
  // Auto = those disappear; only map, telemetry, and camera feed remain.
  bool _manualMode = true;
  Offset _leftStick = Offset.zero;
  Offset _rightStick = Offset.zero;
  Timer? _controlTimer;

  // --- Side Panel Draggable State -----------------------------------
  double? _draggedPanelWidth;
  bool _sidePanelVisible = true;

  // --- Battery warning/critical dialog state -------------------------
  // Warning: pop a confirm-or-cancel RTL dialog. Re-prompts every extra
  // _batteryRepromptStep percent the battery drops past the last time we
  // showed it (so cancelling once doesn't silence it for the whole flight,
  // but it also doesn't nag on every single percent tick).
  // Critical: no dialog — RTL is triggered automatically, no confirmation.
  static const double _batteryWarningThreshold = 20.0;
  static const double _batteryCriticalThreshold = 10.0;
  static const double _batteryRepromptStep = 2.0;
  double? _lastBatteryPromptPercent;
  bool _batteryDialogShowing = false;

  @override
  void initState() {
    super.initState();
    // context.read is safe here: we're not registering a rebuild
    // dependency, just fetching the instances once when this screen is
    // first created.
    _vehicleState = context.read<VehicleState>();
    _connectionManager = context.read<ConnectionManager>();

    WidgetsBinding.instance.addObserver(this);
    _applySystemUISettings();

    // KEPT as addListener on purpose — this drives one-shot side effects
    // (showing a snackbar, centering joysticks, battery warnings), not UI
    // rebuilding. See the note in build() for the part that WAS converted
    // to watch().
    _vehicleState.addListener(_onVehicleStateChanged);

    _controlTimer = Timer.periodic(const Duration(milliseconds: 70), (_) {
      if (_manualMode &&
          _vehicleState.connectionStatus == ConnectionStatus.connected) {
        final throttle = _forceIdleThrottleForArming
            ? -1.0
            : (-_leftStick.dy).clamp(-1.0, 1.0);
        _connectionManager.sendManualControl(
          throttle: throttle,
          yaw: _leftStick.dx,
          pitch: -_rightStick.dy,
          roll: _rightStick.dx,
        );
      }
    });
  }

  void _onManualModeChanged(bool manual) {
    setState(() {
      _manualMode = manual;
      if (!manual) {
        _leftStick = Offset.zero;
        _rightStick = Offset.zero;
        _leftController.center();
        _rightController.center();
      }
    });
  }

  void _onMapTap(double lat, double lon) {
    if (_manualMode) return;

    if (_vehicleState.latitude != null && _vehicleState.longitude != null) {
      final dist = _vehicleState.distanceBetween(
        _vehicleState.latitude!,
        _vehicleState.longitude!,
        lat,
        lon,
      );
      if (dist != null && dist > _vehicleState.commRangeEstimate) {
        _showRangeWarning(dist, () {
          _vehicleState.addWaypoint(lat, lon);
        });
        return;
      }
    }
    _vehicleState.addWaypoint(lat, lon);
  }

  Future<void> _showRangeWarning(
    double distance,
    VoidCallback onContinue,
  ) async {
    final scheme = Theme.of(context).colorScheme;
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: scheme.surface,
        title: const Text('⚠ Communication Range Warning'),
        content: Text(
          'This waypoint is approximately ${distance.toStringAsFixed(0)} m '
          'from the current drone position.\n\n'
          'Configured Wi-Fi range: ${_vehicleState.commRangeEstimate.toStringAsFixed(0)} m\n\n'
          'The drone may lose the MAVLink/Wi-Fi connection while travelling to this location.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              onContinue();
            },
            child: const Text('Continue Anyway'),
          ),
        ],
      ),
    );
  }

  Future<void> _showSearchDialog() async {
    final latController = TextEditingController();
    final lonController = TextEditingController();
    final scheme = Theme.of(context).colorScheme;

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: scheme.surface,
        title: const Text('Search Location'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: latController,
              decoration: const InputDecoration(labelText: 'Latitude'),
              keyboardType: TextInputType.number,
            ),
            TextField(
              controller: lonController,
              decoration: const InputDecoration(labelText: 'Longitude'),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              final lat = double.tryParse(latController.text);
              final lon = double.tryParse(lonController.text);
              if (lat != null && lon != null) {
                Navigator.pop(context);
                _mapKey.currentState?.centerOn(lat, lon);
              }
            },
            child: const Text('Search'),
          ),
        ],
      ),
    );
  }

  Future<void> _applySystemUISettings() async {
    // this makes the joystick stick in landscape layout
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);
    // UI can temporarily appear if the user swipes from an edge, but Flutter will hide it again.
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Android kicks the app back out of immersive mode whenever it's
    // backgrounded and resumed (e.g. the pilot switches apps mid-flight
    // to check something, then comes back). Re-apply it every time we
    // come back to the foreground, or the bars silently reappear.
    if (state == AppLifecycleState.resumed) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }

  // Renamed from the old (never-called) _onArmPressed, and now handles
  // BOTH directions — arm and disarm — since it's the single entry point
  // FlightStatusPanel calls via its onArmToggle callback. Only the arm
  // path forces idle throttle first; disarm doesn't need that.
  Future<void> _onArmToggle(bool arm) async {
    if (arm) {
      setState(() => _forceIdleThrottleForArming = true);
      // Visually snaps the throttle stick to minimum.
      _leftController.moveTo(const Offset(0, 1));

      // Force a manual control packet with -1.0 throttle (idle) IMMEDIATELY.
      // ArduPilot rejects arm commands if the last received throttle wasn't 0.
      await _connectionManager.sendManualControl(
        throttle: -1.0,
        yaw: _leftStick.dx,
        pitch: -_rightStick.dy,
        roll: _rightStick.dx,
      );
    }

    await _connectionManager.armDisarm(arm);

    if (arm) {
      // Wait for the heartbeat to confirm armed, with a safety timeout
      // so a failed/rejected arm doesn't leave throttle stuck at 0 forever.
      final deadline = DateTime.now().add(const Duration(seconds: 3));
      while (!_vehicleState.armed && DateTime.now().isBefore(deadline)) {
        await Future.delayed(const Duration(milliseconds: 100));
      }

      if (mounted) {
        setState(() => _forceIdleThrottleForArming = false);
        // Automatically return throttle to center once armed, as requested.
        // NOTE: In Stabilize mode, this will spin motors to 50% (hover).
        _leftController.center();
      }
    }
  }

  String? _lastMode;

  void _onVehicleStateChanged() {
    final error = _vehicleState.lastError;
    if (error != null && error != _lastShownError) {
      _lastShownError = error;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(error),
            backgroundColor: AppColors.danger,
            behavior: SnackBarBehavior.floating,
          ),
        );
      });
      _vehicleState.clearError();
    }
    if (_vehicleState.currentMode != _lastMode) {
      final previousMode = _lastMode;
      _lastMode = _vehicleState.currentMode;
      if (previousMode != null && _lastMode != 'Stabilize') {
        _leftController.center();
        _rightController.center();
      }
    }

    if (_vehicleState.connectionStatus == ConnectionStatus.timedOut) {
      if (!_timedOutDialogShown) {
        _timedOutDialogShown = true;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _showConnectionTimeoutDialog();
        });
      }
    } else {
      _timedOutDialogShown = false;
    }

    _checkNewAlerts();
    _checkBatteryStatus();
  }

  void _checkNewAlerts() {
    final alert = _vehicleState.lastNewAlert;
    if (alert != null && alert != _lastProcessedAlert) {
      _lastProcessedAlert = alert;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        Color bgColor;
        switch (alert.severity) {
          case AlertSeverity.critical:
            bgColor = AppColors.danger;
            break;
          case AlertSeverity.warning:
            bgColor = AppColors.amber;
            break;
          case AlertSeverity.info:
            bgColor = Theme.of(context).colorScheme.secondary;
            break;
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                Icon(
                  alert.severity == AlertSeverity.critical
                      ? Icons.error
                      : Icons.warning,
                  color: Colors.white,
                ),
                const SizedBox(width: 12),
                Expanded(child: Text(alert.message)),
              ],
            ),
            backgroundColor: bgColor,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 4),
          ),
        );
      });
    }
  }

  Future<void> _showConnectionTimeoutDialog() async {
    final scheme = Theme.of(context).colorScheme;
    final shouldRetry = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: scheme.surface,
        title: Text('connection_timeout'.tr()),
        content: Text('connection_timeout_msg'.tr()),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('dismiss'.tr()),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text('retry'.tr()),
          ),
        ],
      ),
    );
    if (shouldRetry == true && mounted) {
      _connectionManager.connect(ip: '192.168.4.1', port: 14550);
    }
  }

  void _checkBatteryStatus() {
    final battery = _vehicleState.batteryPercent;
    if (battery == null) return;
    if (_vehicleState.connectionStatus != ConnectionStatus.connected) return;

    if (battery <= _batteryCriticalThreshold) {
      // Critical: no confirmation, just go — matches the "if less than a
      // certain level, make it automatically RTL and the person isn't
      // able to do anything" requirement.
      if (_vehicleState.currentMode != 'RTL') {
        _connectionManager.returnToLaunch();
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('critical_battery_msg'.tr()),
              backgroundColor: AppColors.danger,
              behavior: SnackBarBehavior.floating,
            ),
          );
        });
      }
      return;
    }

    if (battery <= _batteryWarningThreshold) {
      final droppedEnoughToReprompt =
          _lastBatteryPromptPercent == null ||
          (_lastBatteryPromptPercent! - battery) >= _batteryRepromptStep;
      if (!_batteryDialogShowing && droppedEnoughToReprompt) {
        _lastBatteryPromptPercent = battery;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _showBatteryDialog(battery);
        });
      }
    } else {
      // Battery recovered above the warning line (e.g. reconnect with a
      // fresh pack) — reset so a future dip re-prompts from scratch.
      _lastBatteryPromptPercent = null;
    }
  }

  Future<void> _showBatteryDialog(double percent) async {
    _batteryDialogShowing = true;
    final scheme = Theme.of(context).colorScheme;
    final shouldReturn = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: scheme.surface,
        title: Text('battery_low'.tr()),
        content: Text(
          'battery_rtl_msg'.tr(
            namedArgs: {'percent': percent.toStringAsFixed(0)},
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('cancel'.tr()),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(context, true),
            child: Text('rtl'.tr().toUpperCase()),
          ),
        ],
      ),
    );
    _batteryDialogShowing = false;
    if (shouldReturn == true) {
      await _connectionManager.returnToLaunch();
    }
  }

  @override
  void dispose() {
    _vehicleState.removeListener(_onVehicleStateChanged);
    _controlTimer?.cancel();
    // _connectionManager.dispose() is NOT called here anymore — main.dart
    // owns that object now, so main.dart is responsible for disposing it.
    _applySystemUISettings();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _onLeftStick(Offset v) => setState(() => _leftStick = v);
  void _onRightStick(Offset v) => setState(() => _rightStick = v);

  void _onTapConnection(bool connected) {
    if (connected) {
      _connectionManager.disconnect();
    } else {
      _connectionManager.connect(ip: '192.168.4.1', port: 14550);
    }
  }

  @override
  Widget build(BuildContext context) {
    // CONVERTED from ListenableBuilder(listenable: _vehicleState, ...) to
    // context.watch — this subscribes the whole build() to VehicleState
    // and reruns it automatically on notifyListeners(), same effect as
    // the old ListenableBuilder wrapper, one less nested widget.
    final vehicleState = context.watch<VehicleState>();
    final settings = context.watch<SettingsController>();

    final connected =
        vehicleState.connectionStatus == ConnectionStatus.connected;
    final hasFix =
        vehicleState.latitude != null && vehicleState.longitude != null;

    // One breakpoint drives every size in this screen — phone gets
    // tighter panels/joysticks/fonts, tablet gets the fuller sizing.
    // Layout shape (map left, side panel right) stays the same on
    // both; only the numbers scale, per Noor's request.
    final tablet = isTabletLayout(context);
    final gap = tablet ? 12.0 : 4.0;

    final defaultSidePanelWidth = tablet ? 260.0 : 135.0;
    final minPanelWidth = tablet ? 100.0 : 60.0;
    final maxPanelWidth = tablet ? 500.0 : 250.0;

    final currentPanelWidth = _sidePanelVisible
        ? (_draggedPanelWidth ?? defaultSidePanelWidth)
        : 0.0;

    final joystickSize = tablet ? 200.0 : 136.0;
    final edgeInset = tablet ? 20.0 : 12.0;
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: scheme.surface,
      body: SafeArea(
        left: false,
        child: Column(
          children: [
            TopBar(
              onTapConnection: () => _onTapConnection(connected),
              manualMode: _manualMode,
              onModeChanged: _onManualModeChanged,
              compact: !tablet,
            ),
            Expanded(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // LEFT: map, with manual-only overlay controls.
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.all(gap),
                      child: Stack(
                        children: [
                          DroneMapView(
                            key: _mapKey,
                            latitude: vehicleState.latitude ?? 33.6844,
                            longitude: vehicleState.longitude ?? 73.0479,
                            headingDegrees: vehicleState.headingDegrees ?? 0,
                            connected: connected,
                            hasFix: hasFix,
                            isDarkMode: settings.isDarkMode,
                            isMapDark: settings.isMapDark,
                            markerStyle: settings.markerStyle,
                            useSatelliteMap: settings.useSatelliteMap,
                            waypoints: vehicleState.missionWaypoints,
                            homeLatitude: vehicleState.homeLatitude,
                            homeLongitude: vehicleState.homeLongitude,
                            currentWaypointIndex:
                                vehicleState.currentWaypointIndex,
                            onTap: _onMapTap,
                            commRangeEstimate: vehicleState.commRangeEstimate,
                          ),
                          if (_manualMode) ...[
                            Positioned(
                              left: edgeInset,
                              bottom: edgeInset,
                              child: Opacity(
                                opacity: connected ? 1 : 0.35,
                                child: IgnorePointer(
                                  ignoring: !connected,
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 10,
                                          vertical: 4,
                                        ),
                                        decoration: BoxDecoration(
                                          color: scheme.surface.withValues(
                                            alpha: 0.8,
                                          ),
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                          border: Border.all(
                                            color: scheme.outlineVariant,
                                          ),
                                        ),
                                        child: Text(
                                          '${(-_leftStick.dy * 100).round()}%',
                                          style: const TextStyle(
                                            color: AppColors.amber,
                                            fontSize: 22,
                                            fontWeight: FontWeight.w900,
                                            fontFamily: 'monospace',
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      settings.joystickStyle ==
                                              JoystickStyle.arrows
                                          ? ArrowJoystick(
                                              label: 'throttle_yaw',
                                              size: joystickSize,
                                              springBack: false,
                                              onChanged: _onLeftStick,
                                              controller: _leftController,
                                            )
                                          : VirtualJoystick(
                                              label: 'throttle_yaw',
                                              size: joystickSize,
                                              springBack: false,
                                              onChanged: _onLeftStick,
                                              controller: _leftController,
                                            ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Positioned(
                              bottom: edgeInset,
                              left: 0,
                              right: 0,
                              child: Center(
                                child: FlightStatusPanel(
                                  enabled: connected,
                                  compact: !tablet,
                                  onArmToggle: _onArmToggle,
                                ),
                              ),
                            ),
                            Positioned(
                              right: edgeInset,
                              bottom: edgeInset,
                              child: Opacity(
                                opacity: connected ? 1 : 0.35,
                                child: IgnorePointer(
                                  ignoring: !connected,
                                  child:
                                      settings.joystickStyle ==
                                          JoystickStyle.arrows
                                      ? ArrowJoystick(
                                          label: 'pitch_roll',
                                          size: joystickSize,
                                          onChanged: _onRightStick,
                                          controller: _rightController,
                                        )
                                      : VirtualJoystick(
                                          label: 'pitch_roll',
                                          size: joystickSize,
                                          onChanged: _onRightStick,
                                          controller: _rightController,
                                        ),
                                ),
                              ),
                            ),
                          ] else ...[
                            // Search Button
                            Positioned(
                              top: 12,
                              left: 60,
                              child: _MapActionButton(
                                icon: Icons.search,
                                onTap: _showSearchDialog,
                                isDarkMode: settings.isDarkMode,
                              ),
                            ),
                            // Mission Planning Panel
                            Positioned(
                              bottom: edgeInset,
                              left: edgeInset,
                              right: edgeInset,
                              child: _MissionPlanningPanel(
                                vehicleState: vehicleState,
                                connectionManager: _connectionManager,
                                tablet: tablet,
                              ),
                            ),
                          ],
                          if (vehicleState.connectionLost)
                            _LastTelemetryOverlay(
                              vehicleState: vehicleState,
                              isDarkMode: settings.isDarkMode,
                            ),

                          // --- DRAG HANDLE / PULL TRIGGER ----------------
                          Positioned(
                            right: 0,
                            top: 0,
                            bottom: 0,
                            child: GestureDetector(
                              behavior: HitTestBehavior.translucent,
                              onHorizontalDragUpdate: (details) {
                                setState(() {
                                  if (!_sidePanelVisible) {
                                    // Pulling out from the right edge
                                    if (details.delta.dx < -5) {
                                      _sidePanelVisible = true;
                                      _draggedPanelWidth =
                                          defaultSidePanelWidth;
                                    }
                                  } else {
                                    // Resizing
                                    final baseWidth =
                                        _draggedPanelWidth ??
                                        defaultSidePanelWidth;
                                    final newWidth =
                                        (baseWidth - details.delta.dx);

                                    if (newWidth < 40) {
                                      _sidePanelVisible = false;
                                      _draggedPanelWidth = 0.0;
                                    } else {
                                      _draggedPanelWidth = newWidth.clamp(
                                        minPanelWidth,
                                        maxPanelWidth,
                                      );
                                    }
                                  }
                                });
                              },
                              child: Container(
                                width: 32, // Large enough grab area
                                color: Colors.transparent,
                                child: Center(
                                  child: Container(
                                    width: 24,
                                    height: 48,
                                    decoration: BoxDecoration(
                                      color: scheme.surface.withValues(
                                        alpha: 0.8,
                                      ),
                                      borderRadius: const BorderRadius.only(
                                        topLeft: Radius.circular(8),
                                        bottomLeft: Radius.circular(8),
                                      ),
                                      border: Border.all(
                                        color: scheme.outlineVariant,
                                      ),
                                    ),
                                    child: IconButton(
                                      padding: EdgeInsets.zero,
                                      icon: Icon(
                                        _sidePanelVisible
                                            ? Icons.chevron_right
                                            : Icons.chevron_left,
                                        size: 20,
                                        color: scheme.primary,
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          _sidePanelVisible =
                                              !_sidePanelVisible;
                                          if (_sidePanelVisible) {
                                            _draggedPanelWidth =
                                                defaultSidePanelWidth;
                                          }
                                        });
                                      },
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // RIGHT: side panel — camera feed on top, telemetry below.
                  // Width is dynamic, and can be hidden (0 width).
                  if (currentPanelWidth > 0)
                    SizedBox(
                      width: currentPanelWidth,
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(0, gap, gap, gap),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            CameraFeedPanel(connected: true, compact: !tablet),
                            SizedBox(height: gap),
                            Expanded(child: TelemetryPanel(compact: !tablet)),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MapActionButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool isDarkMode;

  const _MapActionButton({
    required this.icon,
    required this.onTap,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    final bg = isDarkMode ? AppColors.surface : Colors.white;
    final border = isDarkMode ? AppColors.hairline : Colors.black12;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: bg.withValues(alpha: 0.92),
          shape: BoxShape.circle,
          border: Border.all(color: border),
          boxShadow: const [
            BoxShadow(
              color: Colors.black38,
              blurRadius: 10,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: Icon(icon, size: 20, color: AppColors.amber),
      ),
    );
  }
}

class _MissionPlanningPanel extends StatelessWidget {
  final VehicleState vehicleState;
  final ConnectionManager connectionManager;
  final bool tablet;

  const _MissionPlanningPanel({
    required this.vehicleState,
    required this.connectionManager,
    required this.tablet,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final wps = vehicleState.missionWaypoints;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: scheme.surface.withValues(alpha: 0.9),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: scheme.outlineVariant),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Mission: ${wps.length} Waypoints',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              const Text('RTL After:'),
              Switch(
                value: vehicleState.rtlAfterMission,
                onChanged: (v) => vehicleState.setRtlAfterMission(v),
                activeTrackColor: AppColors.amber.withOpacity(0.5),
                activeThumbColor: AppColors.amber,
              ),
              IconButton(
                icon: const Icon(Icons.delete_sweep),
                onPressed: () => vehicleState.clearMission(),
                tooltip: 'Clear Mission',
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed:
                      vehicleState.missionUploadStatus ==
                          MissionUploadStatus.uploading
                      ? null
                      : () => connectionManager.uploadMission(),
                  icon: const Icon(Icons.upload),
                  label: Text(
                    vehicleState.missionUploadStatus ==
                            MissionUploadStatus.uploading
                        ? 'Uploading...'
                        : 'Upload Mission',
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: FilledButton.icon(
                  onPressed:
                      vehicleState.missionUploadStatus ==
                          MissionUploadStatus.success
                      ? () => connectionManager.startAuto()
                      : null,
                  icon: const Icon(Icons.play_arrow),
                  label: const Text('START AUTO'),
                  style: FilledButton.styleFrom(
                    backgroundColor: AppColors.success,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _LastTelemetryOverlay extends StatelessWidget {
  final VehicleState vehicleState;
  final bool isDarkMode;

  const _LastTelemetryOverlay({
    required this.vehicleState,
    required this.isDarkMode,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final lastUpdate = vehicleState.lastHeartbeat;
    final timeStr = lastUpdate != null
        ? DateFormat('HH:mm:ss').format(lastUpdate)
        : 'Unknown';

    return Container(
      color: Colors.black54,
      child: Center(
        child: Container(
          width: 300,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: scheme.surface,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Row(
                children: [
                  Icon(Icons.error, color: AppColors.danger),
                  SizedBox(width: 8),
                  Text(
                    'CONNECTION LOST',
                    style: TextStyle(
                      color: AppColors.danger,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              const Text(
                'Last Received Telemetry',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const Divider(),
              _TelemetryRow(
                label: 'Position',
                value:
                    '${vehicleState.latitude?.toStringAsFixed(5)}, ${vehicleState.longitude?.toStringAsFixed(5)}',
              ),
              _TelemetryRow(
                label: 'Altitude',
                value: '${vehicleState.altitudeMeters?.toStringAsFixed(1)} m',
              ),
              _TelemetryRow(
                label: 'Battery',
                value: '${vehicleState.batteryPercent?.toStringAsFixed(0)}%',
              ),
              _TelemetryRow(
                label: 'Speed',
                value: '${vehicleState.speedMps?.toStringAsFixed(1)} m/s',
              ),
              _TelemetryRow(
                label: 'Flight Mode',
                value: vehicleState.currentMode,
              ),
              _TelemetryRow(label: 'Last Update', value: timeStr),
              const SizedBox(height: 16),
              const Text(
                '⚠ Values shown are the last received telemetry.',
                style: TextStyle(fontSize: 10, fontStyle: FontStyle.italic),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () {
                  // Could trigger a reconnect attempt here
                },
                child: const Text('RETRY CONNECTION'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TelemetryRow extends StatelessWidget {
  final String label;
  final String value;

  const _TelemetryRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: Colors.grey)),
          Text(value, style: const TextStyle(fontFamily: 'monospace')),
        ],
      ),
    );
  }
}
