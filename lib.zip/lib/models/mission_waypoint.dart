class MissionWaypoint {
  final double latitude;
  final double longitude;
  final double altitude;
  final int sequence;

  MissionWaypoint({
    required this.latitude,
    required this.longitude,
    required this.altitude,
    required this.sequence,
  });

  MissionWaypoint copyWith({
    double? latitude,
    double? longitude,
    double? altitude,
    int? sequence,
  }) {
    return MissionWaypoint(
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      altitude: altitude ?? this.altitude,
      sequence: sequence ?? this.sequence,
    );
  }
}
